import bpy


class exePanel(bpy.types.Panel):

    bl_label = "Execution Pannel"
    bl_idname = "SCENE_PT_execution"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'TOOLS'
    bl_context = "tools"

    def draw(self, context):
        layout = self.layout

        scene = context.scene

        # Big render button
        layout.label(text="Render button:")
        row = layout.row()
        row.scale_y = 1.0
        row.operator("render.render")

        # Big execute button
        layout.label(text="Trees execution button:")
        row = layout.row()
        row.scale_y = 1.0
        row.operator("test.custom")

        # Big execute button
        layout.label(text="Trees export button:")
        row = layout.row()
        row.scale_y = 1.0
        row.operator("test.export")