import bpy
import time
import json


print('Node tree file read')

class EONodeTree(bpy.types.NodeTree):
    """ Earth Observation Node Editor"""

    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'eo_EarthObservationTreeType'
    # Label for nice name display
    bl_label = "Earth Observation Node Tree"
    # Icon identifier
    bl_icon = 'IMAGE_RGB'

    @property
    def timestamp(self):
        return time.monotonic()

    def exportJson(self, tree_name):
        # json initialisation
        treejson = {
            'id': self.bl_idname,
            'name': tree_name,
            'nodes':[],
            'links':[]
            }
        
        # json links
        for i in self.links.items():
            link = {
                'from_node_id': i[-1].from_node.bl_idname,
                'from_node_socket': i[-1].from_socket.name,
                'to_node_id': i[-1].to_node.bl_idname,
                'to_node_socket': i[-1].to_socket.name,
            }
            treejson['links'].append(link)
        
        # json nodes
        for i in self.nodes.items():
            node = {
                'node_id': i[-1].bl_idname,
                'inputs_no_socket': []
            }
            inputs = {}
            for j in i[-1].items():
                inputs[j[0]] = j[1]
            node['inputs_no_socket'].append(inputs)

            treejson['nodes'].append(node)
        return json.dumps(treejson)

    def execute(self):
        print('tree update function, number of nodes to update:', len(self.nodes.items()))
        
        for i in self.nodes.items():
            print('Executing node:',i[0])
            i[-1].process()
