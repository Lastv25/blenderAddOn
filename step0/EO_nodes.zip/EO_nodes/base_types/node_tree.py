import bpy
import time


print('Node tree file read')

class EONodeTree(bpy.types.NodeTree):
    """ Earth Observation Node Editor"""

    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'eo_EarthObservationTreeType'
    # Label for nice name display
    bl_label = "Earth Observation Node Tree"
    # Icon identifier
    bl_icon = 'IMAGE_RGB'

    @property
    def timestamp(self):
        return time.monotonic()

    def execute(self):
        print('tree update function, number of nodes to update:', len(self.nodes.items()))
        for i in self.nodes.items():
            print(i)
            print(i[-1].process())