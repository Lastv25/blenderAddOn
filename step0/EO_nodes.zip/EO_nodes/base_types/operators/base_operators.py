import bpy



class ExecuteTreeCustom(bpy.types.Operator):
    bl_idname = "test.custom"
    bl_label = "Run Tree"

    def execute(self, context):
        for i in bpy.data.node_groups:
            #print(i.bl_idname)
            if i.bl_idname == 'eo_EarthObservationTreeType':
                i.execute()
        return {'FINISHED'}

class ExportTreeCustom(bpy.types.Operator):
    bl_idname = "test.export"
    bl_label = "Export Tree"

    def execute(self, context):
        for i in bpy.data.node_groups:
            if i.bl_idname == 'eo_EarthObservationTreeType':
                print(i.exportJson(i.name))
        return {'FINISHED'}
