import bpy
from ... algorithms import hub_queries
import requests
import os


class DownloadNode(bpy.types.Node):
  

    bl_idname = 'DownloadNode'

    bl_label = "Download Product Node"

    bl_icon = 'ZOOM_SELECTED'


    def items_update(self, context):
        items_new = []
        if self.inputs['prodList'].is_linked and self.inputs['prodList'].links[0].is_valid:
            input_products = self.inputs['prodList'].links[0].from_socket.default_value.split('<')[2:]
            for i in range(len(input_products)):
                prod = input_products[i].split('.SAFE')[0]
                items_new.append((prod, prod, 'prod'+str(i),i))
        return items_new

    filepath: bpy.props.StringProperty()
    prod_list: bpy.props.EnumProperty(items=items_update,description='',get=None,set=None,update=None,default=None)


    def init(self, context):
        self.outputs.new('NodeSocketString', "status")
        self.inputs.new('NodeSocketString', "prodList")

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        print("Copying from node ", node)

    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")

    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        layout.label(text="FilePath")
        layout.prop(self, "filepath")
        layout.prop(self, "prod_list")

    def process(self):
        if len(self.filepath) > 0:
            N_username = self.inputs['prodList'].links[0].from_socket.default_value.split('<')[1]
            N_password = self.inputs['prodList'].links[0].from_socket.default_value.split('<')[0]
            uuid, contentLength  = hub_queries.get_uuid_from_name(self.prod_list, N_password, N_username)
            
            if os.path.isdir(self.filepath):
                url = "https://scihub.copernicus.eu/dhus/odata/v1/Products('uuid')/$value".replace('uuid',uuid)
                print(url)
                print(contentLength)
                current_size = 0 
                with requests.get(url, auth=(N_username,N_password), stream=True) as r:
                    r.raise_for_status()
                    with open(self.filepath+self.prod_list, 'wb') as f:
                        for chunk in r.iter_content(chunk_size=10*1024):
                            if chunk:
                                current_size += 1024*10
                                print(current_size, current_size/int(contentLength))
                                f.write(chunk)
                
            else:
                print('filepath not valid')
        return {'FINISHED'}