import bpy

# Socket type used by the EO nodes
class EOSocket(bpy.types.NodeSocket):
    # Description string
    '''EO nodes's sockets'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'EOSocketType'
    # Label for nice name display
    bl_label = "Earth Observation Node Socket"

    # Enum items list
    my_items = (
        ('DOWN', "Down", "Where your feet are"),
        ('UP', "Up", "Where your head should be"),
        ('LEFT', "Left", "Not right"),
        ('RIGHT', "Right", "Not left"),
    )

    my_enum_prop: bpy.props.EnumProperty(
        name="Direction",
        description="Just an example",
        items=my_items,
        default='UP',
    )

    # Optional function for drawing the socket input value
    def draw(self, context, layout, node, text):
        if self.is_output or self.is_linked:
            layout.label(text=text)
        else:
            layout.prop(self, "my_enum_prop", text=text)

    # Socket color
    def draw_color(self, context, node):
        return (1.0, 0.4, 0.216, 0.5)



class TestSocket(bpy.types.NodeSocket):

    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'TestSocket'
    # Label for nice name display
    bl_label = "Test Node Socket"

    def my_callback(self, context):
        print('Socket callback function')

    my_socket_value: bpy.props.StringProperty(name='test socket', default="Hello", update=my_callback)

    #my_socket_value: bpy.props.StringProperty(name='test socket', default="Hello")

    # Optional function for drawing the socket input value
    def draw(self, context, layout, node, text):
        if self.is_output or self.is_linked:
            #print(my_socket_value)
            layout.label(text=text)
        else:
            layout.prop(self, "TestSocket", text=text)

        # Socket color
    def draw_color(self, context, node):
        return (1.0, 0.4, 0.216, 0.5)

    
    def set_value(self, new_value):
        self.my_socket_value = new_value