import os
import requests

def odata_query_creation(longitude, latitude, prod_type, time_type, date):
    geom_txt = 'footprint:"Intersects('+str(latitude)+','+str(longitude)+')"'
    product_type = 'producttype:'+prod_type
    if time_type == 'INDATE':
        time_filter = 'ingestiondate:'+date+'T00:00:00.000Z TO '+date+'T24:00:00.000Z'
    elif time_type == 'CREADATE':
        time_filter = 'creationdate:'+date+'T00:00:00.000Z TO '+date+'T24:00:00.000Z'
    else:
        time_filter = ''
    query = 'https://scihub.copernicus.eu/server/search?start=0&rows=10&q=('
    return query+geom_txt+' AND '+product_type+')'


def download_product_list(url, N_password, N_username):
    r = requests.get(url, auth=(N_username,N_password))
    if r.status_code == 200:
        response = r.text
        t = response.split('<str name="filename">')
        for i in range(len(t)):
            t[i] = t[i].split('/')[0]
    else:
        print('Status code', r.status_code)
        return []
    return t

def get_uuid_from_name(name,N_password,N_username):
    url = "https://scihub.copernicus.eu/dhus/odata/v1/Products?filter=Name= eq 'name'".replace("name",name)
    r = requests.get(url, auth=(N_username,N_password))
    if r.status_code == 200:
        response = r.text
        uuid = response.split('<m:properties><d:Id>')[1].split('</d:Id>')[0]
        length = response.split('<d:ContentLength>')[1].split('</d:ContentLength>')[0]
        return uuid,length
    else:
        print('Status code', r.status_code)
        return '',''
        