import bpy



class ExecuteTreeCustom(bpy.types.Operator):
    bl_idname = "test.custom"
    bl_label = "Minimal Operator"

    def execute(self, context):
        for i in bpy.data.node_groups:
            if i.bl_idname == 'eo_EarthObservationTreeType':
                i.execute()
        return {'FINISHED'}
