import bpy
from ... algorithms import hub_queries

missions_Ids = [
    ("S1A", "s1a", "S1A_", "", 0),
    ("S1B", "s1b", "S1B_", "", 1),
    ("S2A", "s2a", "S2A_", "", 2),
    ("S2B", "s2b", "S2B_", "", 3),
    ("S3A", "s3a", "S3A_", "", 4),
    ("S3B", "s3b", "S3B_", "", 5)]

time_filters = [
    ("INDATE", "IngestionDate", "indate", "", 0),
    ("CREADATE", "CreationDate", "creadate", "", 1),
    ("CONTENTDATESTART", "ContentDateStart", "conDateStart", "", 2),
    ("CONTENTDATEEND", "ContentDateEnd", "conDateEnd", "", 3)]

class ProdChoiceNode(bpy.types.Node):
  
    '''Node that presents no imputs but will create an Odata query to select a copernicus
    product based on the coordinates (latitude, longitude), the date and the mission. The 
    output socket is a string'''

    bl_idname = 'ProdChoiceNode'

    bl_label = "Product Choice Node"

    bl_icon = 'ZOOM_SELECTED'


    my_string_prop: bpy.props.StringProperty()
    latitude: bpy.props.FloatProperty(min=-90, max=90, default=0)
    longitude: bpy.props.FloatProperty(min=-180, max=180, default=0)
    missions: bpy.props.EnumProperty(name='Missions', items=missions_Ids)
    time_types: bpy.props.EnumProperty(name='Time_Filters', items=time_filters)
    date: bpy.props.StringProperty(default='2017-01-01')


    def init(self, context):
        self.outputs.new('NodeSocketString', "Odata query")

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        print("Copying from node ", node)

    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")

    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        layout.label(text="OData Filters")
        layout.prop(self, "latitude")
        layout.prop(self, "longitude")
        layout.prop(self, "missions")
        layout.prop(self, "time_types")
        layout.prop(self, "date")

    def process(self):
        self.outputs['Odata query'].default_value = 'Coucou'
        print(self.outputs['Odata query'].default_value)
        print('Code executed')
