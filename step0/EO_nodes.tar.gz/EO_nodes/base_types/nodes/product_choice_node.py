import bpy
from ... algorithms import hub_queries

type_ids = [
    ("SLC", "slc", "SLC", "", 0),
    ("GRD", "grd", "GRD", "", 1),
    ("OCN", "ocn", "OCN", "", 2),
    ("S2MSI2A", "s2msi2a", "S2MSI2A", "", 3),
    ("S2MSI1C", "s2msi1c", "S2MSI1C", "", 4),
    ("S2MSI2Ap", "s2msi2ap", "S2MSI2Ap", "", 5)]

time_filters = [
    ("INDATE", "IngestionDate", "indate", "", 0),
    ("CREADATE", "CreationDate", "creadate", "", 1),
    ("CONTENTDATESTART", "ContentDateStart", "conDateStart", "", 2),
    ("CONTENTDATEEND", "ContentDateEnd", "conDateEnd", "", 3)]

class ProdChoiceNode(bpy.types.Node):
  
    '''Node that presents no imputs but will create an Odata query to select a copernicus
    product based on the coordinates (latitude, longitude), the date and the mission. The 
    output socket is a string'''

    bl_idname = 'ProdChoiceNode'

    bl_label = "Product Choice Node"

    bl_icon = 'ZOOM_SELECTED'


    my_string_prop: bpy.props.StringProperty()
    latitude: bpy.props.FloatProperty(min=-90, max=90, default=0)
    longitude: bpy.props.FloatProperty(min=-180, max=180, default=0)
    ptypes: bpy.props.EnumProperty(name='ProdTypes', items=type_ids)
    time_types: bpy.props.EnumProperty(name='Time_Filters', items=time_filters)
    date: bpy.props.StringProperty(default='2017-01-01')


    def init(self, context):
        self.outputs.new('NodeSocketString', "Odata query")

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        print("Copying from node ", node)

    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")

    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        layout.label(text="OData Filters")
        layout.prop(self, "latitude")
        layout.prop(self, "longitude")
        layout.prop(self, "ptypes")
        layout.prop(self, "time_types")
        layout.prop(self, "date")

    def process(self):
        query = hub_queries.odata_query_creation(self.longitude,self.latitude,self.ptypes,self.time_types,self.date) 
        if self.outputs['Odata query'].is_linked:
            self.outputs['Odata query'].default_value = query
        #print(self.outputs['Odata query'].default_value)
        #print('Code executed')
        return {'FINISHED'}
