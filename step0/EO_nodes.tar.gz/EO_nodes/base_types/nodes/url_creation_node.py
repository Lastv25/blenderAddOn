import bpy
from ... base_types import TestSocket

servers_names = [
    ("dhus", "DHUS", "dhus", "", 0)]

class URLCreationNode(bpy.types.Node):
  
    '''Node that presents no imputs but will create an Odata query to select a copernicus
    product based on the coordinates (latitude, longitude), the date and the mission. The 
    output socket is a string'''

    bl_idname = 'URLCreationNode'

    bl_label = "URL Creation Node"

    bl_icon = 'ZOOM_SELECTED'


    my_string_prop: bpy.props.StringProperty()
    servers: bpy.props.EnumProperty(name='servers', items=servers_names)



    def init(self, context):
        self.outputs.new('NodeSocketString', "URL")

        self.inputs.new('TestSocket', "Odata_query")

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        print("Copying from node ", node)

    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")

    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        layout.label(text="Server parameters")
        layout.prop(self, "servers")

    def process(self):
        if self.inputs['Odata_query'].is_linked and self.inputs['Odata_query'].links[0].is_valid:
            #print('url input links:',self.inputs['Odata_query'].links[0].from_socket.default_value)
            input_value = self.inputs['Odata_query'].links[0].from_socket.default_value
            self.outputs["URL"].default_value = input_value.replace('server', self.servers)
            #self.inputs['Odata_query'].set_value(input_value)
        return {'FINISHED'}
