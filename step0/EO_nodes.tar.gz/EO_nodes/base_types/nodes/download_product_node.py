import bpy



class DownloadNode(bpy.types.Node):
  
    '''Node that presents no imputs but will create an Odata query to select a copernicus
    product based on the coordinates (latitude, longitude), the date and the mission. The 
    output socket is a string'''

    bl_idname = 'DownloadNode'

    bl_label = "Download Product Node"

    bl_icon = 'ZOOM_SELECTED'


    my_string_prop: bpy.props.StringProperty()
    filepath: bpy.props.StringProperty()


    def init(self, context):
        self.outputs.new('NodeSocketString', "status")

        self.inputs.new('NodeSocketString', "URL")

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        print("Copying from node ", node)

    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")

    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        layout.label(text="Download file path")
        layout.prop(self, "filepath")
