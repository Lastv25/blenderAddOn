import urllib3
import os

def odata_query_creation(longitude, latitude, mission, time):
    print('Odata query creation function zas called')

def url_creation(odata_query, server, username, password):
    pass

def download_product(local_path, url):
    pass

